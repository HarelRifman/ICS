#include <stdio.h>
#include <math.h>
int main() {
   char num1,num1_1,num1_2,num1_3;
   char num2,num2_1,num2_2,num2_3;
   char result,result1,result2,result3;
   
   //Ex1- adds two binery numbers 
   printf("Exercise 1:\n");
   printf("Enter 2 binary string with 4 digits: \n");
   printf("Binery1: ");
   scanf("%c%c%c%c", &num1,&num1_1,&num1_2,&num1_3);
   printf("Binery2:\n");
   scanf("%c%c%c%c", &num2,&num2_1,&num2_2,&num2_3);
   printf("%c%c%c%c\n", num1,num1_1,num1_2,num1_3);
   printf("^")
   printf("%c%c%c%c\n", num2,num2_1,num2_2,num2_3)
   printf("--------\n")
   result = num1^num2;
   result1 = num1_1^num2_1;
   result2 = num1_2^num2_2;
   result3 = num1_3^num2_3;

   printf("%d%d%d%d\n", result, result1, result2, result3);



   //Ex2- adds two hex numbers and prints the first 4 bits of the result
   unsigned int firstHex, secondHex, sum;
   int sumBits[5];
   printf("Exercise 2:\n");
   printf("Enter two hexadecimal numbers: \n");
   printf("Hexa 1: ");
   scanf("%X", &firstHex);
   printf("Hex 2: \n");
   scanf("%X", &secondHex);
   sum = firstHex + secondHex;
   
   sumBits[0] = sum & 1;
   sum >>= 1;
   sumBits[1] = sum & 1;
   sum >>= 1;
   sumBits[2] = sum & 1;
   sum >>= 1;
   sumBits[3] = sum & 1;
   sum >>= 1;
   

   printf("The last 4 binery digits of the sum are: %d%d%d%d\n", sumBits[0],sumBits[1],sumBits[2],sumBits[3]);
   

   //Ex3- A program that requests a base between 2 and 9 and a 5-digit number written in the selected base. The program will return the
   //The decimal representation of the number
    printf("Exercise 3:\n");
    int base, integer,dec;

    
    printf("Choose a number between 2 to 9: ");
    scanf("%d", &base);

    printf("Enter a 5 digit number using that base: ");
    scanf("%d", &integer);

    dec = integer%10 +
      (pow(base, 1)) * ((integer % 100) / 10) +
      (pow(base, 2)) * ((integer % 1000) / 100) +
      (pow(base, 3)) * ((integer % 10000) / 1000) +
      (base*base*base*base) * (integer / 10000);
     
    printf("The decimal value of %d in base %d is %d\n", integer, base, dec);  
    //Ex-4 A program that asks for a number of people, then asks for the index of one of the bits, the program will return the value of the requested bit in the binary representation of
    //The number entered.
    printf("Exercise 4:\n");

    int originalNumber, bitOrder;
    printf("Enter a number: ");
    scanf("%d", &originalNumber);

    printf("I want to know the value of bit number: \n");
    scanf("%d", &bitOrder);

    // Right-shift the originalNumber by the bitOrder
    int bitValue = (originalNumber >> (bitOrder -1)) & 1;

    printf("The value of bit number %d is %d\n", bitOrder, bitValue);

    printf("Congrats! You've found the philosopher's stone!");
    return 0;
}